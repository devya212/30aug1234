package com.nucleus.dao;

import com.nucleus.model.Customer;

public interface ICustomerDao {
public void saveCustomer(Customer customer);
}
